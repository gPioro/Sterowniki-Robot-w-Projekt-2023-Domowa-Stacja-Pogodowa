/*
 * driver_aht20_basic.h
 *
 *  Created on: 6 июн. 2023 г.
 *      Author: danza
 */

#ifndef INC_DRIVER_AHT20_BASIC_H_
#define INC_DRIVER_AHT20_BASIC_H_

#include "driver_aht20_interface.h"

#ifdef __cplusplus
 extern "C"{
#endif

 uint8_t aht20_basic_init(void);

 uint8_t aht20_basic_deinit(void);

 uint8_t aht20_basic_read(float *temperature, uint8_t *humidity);

#ifdef __cplusplus
}
#endif

#endif /* INC_DRIVER_AHT20_BASIC_H_ */
