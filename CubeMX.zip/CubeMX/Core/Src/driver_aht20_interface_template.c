 #include "driver_aht20_interface.h"

 uint8_t aht20_interface_iic_init(void)
 {
     return 0;
 }

 uint8_t aht20_interface_iic_deinit(void)
 {
     return 0;
 }

 uint8_t aht20_interface_iic_read_cmd(uint8_t addr, uint8_t *buf, uint16_t len)
 {
     return 0;
 }

 uint8_t aht20_interface_iic_write_cmd(uint8_t addr, uint8_t *buf, uint16_t len)
 {
     return 0;
 }

 void aht20_interface_delay_ms(uint32_t ms)
 {

 }

 void aht20_interface_debug_print(const char *const fmt, ...)
 {

 }
